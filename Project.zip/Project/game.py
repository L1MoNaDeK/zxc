import csv
import math
import os
import random
import sys
from string import ascii_letters

import pygame


def terminate():
    pygame.quit()
    sys.exit()


def load_image(name, colorkey=None):
    fullname = os.path.join('data\images', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


class Button:
    def create_button(self, surface, color, x, y, length, height,
                      width, text, text_color):
        self.text = text
        self.color = color
        self.text_color = text_color
        surface = self.draw_button(surface, color, length, height, x, y, width)
        surface = self.write_text(surface, text, text_color,
                                  length, height, x, y)
        self.rect = pygame.Rect(x, y, length, height)
        return surface

    def write_text(self, surface, text, text_color, length, height, x, y):
        font_size = int(length // len(text))
        myFont = pygame.font.SysFont("Calibri", font_size)
        myText = myFont.render(text, 1, text_color)
        surface.blit(myText, ((x + length / 2) - myText.get_width() / 2,
                              (y + height / 2) - myText.get_height() / 2))
        return surface

    def draw_button(self, surface, color, length, height, x, y, width):
        for i in range(1, 10):
            s = pygame.Surface((length + (i * 2), height + (i * 2)))
            s.fill(color)
            alpha = (255 / (i + 2))
            if alpha <= 0:
                alpha = 1
            s.set_alpha(alpha)
            pygame.draw.rect(s, color, (x - i, y - i, length + i, height + i),
                             width)
            surface.blit(s, (x - i, y - i))
        pygame.draw.rect(surface, color, (x, y, length, height), 0)
        pygame.draw.rect(surface, (190, 190, 190), (x, y, length, height), 1)
        return surface

    def pressed(self, mouse):
        try:
            a = self.rect.topleft[0]
        except:
            return False
        if mouse[0] > self.rect.topleft[0]:
            if mouse[1] > self.rect.topleft[1]:
                if mouse[0] < self.rect.bottomright[0]:
                    if mouse[1] < self.rect.bottomright[1]:
                        return True
                    else:
                        return False
                else:
                    return False
            else:
                return False
        else:
            return False

    def volume_btn(self, state):
        self.state = state


def main_menu(screen):
    global game_state
    game_state = 0
    screen.blit(fon, (0, 0))

    head1.create_button(screen, (79, 28, 140), 680, 120, 240, 40, 40,
                        ' ', (255, 255, 255))
    head2.create_button(screen, (98, 36, 173), 690, 110, 220, 60, 60,
                        ' ', (255, 255, 255))
    head3.create_button(screen, (120, 44, 212), 700, 100, 200, 80, 80,
                        'Спасение космоса', (255, 255, 255))
    play_btn.create_button(screen, (95, 70, 125), 700, 200, 200, 80, 80,
                           'Играть', (28, 4, 59))
    settings_btn.create_button(screen, (95, 70, 125), 700, 300, 200, 80, 80,
                               'Настройки', (28, 4, 59))
    help_btn.create_button(screen, (95, 70, 125), 700, 400, 200, 80, 80,
                           'Предыстория', (28, 4, 59))
    quit_btn.create_button(screen, (95, 70, 125), 700, 500, 200, 80, 80,
                           'Выход', (28, 4, 59))

    pygame.display.flip()


def hide_menu():
    head1.create_button(screen, (0, 0, 0), -1600, -900,
                        1, 1, 1, '-', (0, 0, 0))
    head2.create_button(screen, (0, 0, 0), -1600, -900,
                        1, 1, 1, '-', (0, 0, 0))
    head3.create_button(screen, (0, 0, 0), -1600, -900,
                        1, 1, 1, '-', (0, 0, 0))
    play_btn.create_button(screen, (0, 0, 0), -1600, -900,
                           1, 1, 1, '-', (0, 0, 0))
    settings_btn.create_button(screen, (0, 0, 0), -1600, -900,
                               1, 1, 1, '-', (0, 0, 0))
    help_btn.create_button(screen, (0, 0, 0), -1600, -900,
                           1, 1, 1, '-', (0, 0, 0))
    quit_btn.create_button(screen, (0, 0, 0), -1600, -900,
                           1, 1, 1, '-', (0, 0, 0))
    for i in volume_btns:
        i.create_button(screen, (0, 0, 0), -1600, -900,
                        1, 1, 1, '-', (0, 0, 0))


def other_menu(screen):
    global game_state
    click_sound.play()
    game_state = 3
    screen.blit(fon, (0, 0))
    hide_menu()

    box.create_button(screen, (95, 70, 125), 500, 50, 600, 800, 800,
                      ' ', (255, 255, 255))
    to_menu.create_button(screen, (95, 70, 125), 1520, 20, 60, 60, 60,
                          '\u2192', (15, 10, 20))
    text = font_header.render('Предыстория', True, (28, 4, 59))
    text_x = width // 2 - text.get_width() // 2
    screen.blit(text, (text_x, 70))
    lore_image = load_image(r"png/lore.png")
    lore_image = pygame.transform.scale(lore_image, (580, 740))
    img_x = width // 2 - lore_image.get_width() // 2
    screen.blit(lore_image, (img_x, 100))

    pygame.display.flip()


def settings_menu(screen):
    global game_state
    click_sound.play()
    game_state = 2
    screen.blit(fon, (0, 0))
    hide_menu()

    box.create_button(screen, (95, 70, 125), 500, 50, 600, 800, 800,
                      ' ', (255, 255, 255))
    to_menu.create_button(screen, (95, 70, 125), 1520, 20, 60, 60, 60,
                          '\u2192', (15, 10, 20))
    text = font_header.render('Настройки', True, (28, 4, 59))
    text_x = width // 2 - text.get_width() // 2
    screen.blit(text, (text_x, 80))
    text = font_header.render('Музыка:', True, (28, 4, 59))
    screen.blit(text, (520, 140))

    if volume_main.state:
        volume_main.create_button(screen, (34, 191, 13), 640, 130, 40, 40, 40,
                                  'Вкл', (255, 255, 255))
    else:
        volume_main.create_button(screen, (68, 71, 67), 640, 130, 40, 40, 40,
                                  'Выкл', (255, 255, 255))
    x = 700
    y = 130
    cond = False
    for i in range(10):
        if volume_main.state:
            if volume_btns[i].state:
                color = (95, 237, 95)
                cond = True
            else:
                if cond is False:
                    color = (34, 191, 13)
                else:
                    color = (68, 71, 67)
        else:
            if volume_btns[i].state:
                color = (116, 128, 115)
                cond = True
            else:
                if cond is False:
                    color = (93, 97, 93)
                else:
                    color = (68, 71, 67)
        volume_btns[i].create_button(screen, color, x, y, 20, 40, 40,
                                     ' ', (255, 255, 255))
        x += 40

    text = font_header.render('Эффекты:', True, (28, 4, 59))
    screen.blit(text, (520, 200))
    if effects_main.state:
        effects_main.create_button(screen, (34, 191, 13), 640, 190, 40, 40, 40,
                                   'Вкл', (255, 255, 255))
    else:
        effects_main.create_button(screen, (68, 71, 67), 640, 190, 40, 40, 40,
                                   'Выкл', (255, 255, 255))
    x = 700
    y = 190
    cond = False
    for i in range(10):
        if effects_main.state:
            if effects_btns[i].state:
                color = (95, 237, 95)
                cond = True
            else:
                if cond is False:
                    color = (34, 191, 13)
                else:
                    color = (68, 71, 67)
        else:
            if effects_btns[i].state:
                color = (116, 128, 115)
                cond = True
            else:
                if cond is False:
                    color = (93, 97, 93)
                else:
                    color = (68, 71, 67)
        effects_btns[i].create_button(screen, color, x, y, 20, 40, 40,
                                      ' ', (255, 255, 255))
        x += 40

    text = font_header.render('Управление', True, (28, 4, 59))
    text_x = width // 2 - text.get_width() // 2
    screen.blit(text, (text_x, 260))
    color = (95, 237, 95)

    if wasd_box.state:
        wasd_box.create_button(screen, (34, 191, 13), 575, 310, 200, 200, 200,
                               ' ', (255, 255, 255))
    else:
        color = (68, 71, 67)
        wasd_box.create_button(screen, (68, 71, 67), 575, 310, 200, 200, 200,
                               ' ', (255, 255, 255))
    w_btn.create_button(screen, color, 655, 350, 40, 40, 40, 'W', (25, 25, 25))
    a_btn.create_button(screen, color, 595, 410, 40, 40, 40, 'A', (25, 25, 25))
    s_btn.create_button(screen, color, 655, 410, 40, 40, 40, 'S', (25, 25, 25))
    d_btn.create_button(screen, color, 715, 410, 40, 40, 40, 'D', (25, 25, 25))

    if arrow_box.state:
        arrow_box.create_button(screen, (34, 191, 13), 825, 310, 200, 200, 200,
                                ' ', (255, 255, 255))
    else:
        color = (68, 71, 67)
        arrow_box.create_button(screen, (68, 71, 67), 825, 310, 200, 200, 200,
                                ' ', (255, 255, 255))
    arrowUp_btn.create_button(screen, color, 905, 350, 40, 40, 40,
                              '\u2191', (255, 255, 255))
    arrowLeft_btn.create_button(screen, color, 845, 410, 40, 40, 40,
                                '\u2190', (255, 255, 255))
    arrowDown_btn.create_button(screen, color, 905, 410, 40, 40, 40,
                                '\u2193', (255, 255, 255))
    arrowRight_btn.create_button(screen, color, 965, 410, 40, 40, 40,
                                 '\u2192', (255, 255, 255))

    pygame.display.flip()


def volume(sender):
    click_sound.play()
    if sender is volume_main:
        if volume_main.text == 'Вкл':
            pygame.mixer.music.stop()
            volume_main.volume_btn(False)
        else:
            pygame.mixer.music.play()
            volume_main.volume_btn(True)
    else:
        count = volume_btns.index(sender)
        volume_states = [False, False, False, False, False,
                         False, False, False, False, False]
        volume_states[count] = True
        for i in range(len(volume_btns)):
            volume_btns[i].state = volume_states[i]
        pygame.mixer.music.set_volume((count + 1) / 10)
    settings_menu(screen)
    pygame.display.flip()


def effects_volume(sender):
    global effects_vol
    if sender is effects_main:
        if effects_main.text == 'Вкл':
            effects_main.volume_btn(False)
            shoot_sound.set_volume(0)
            click_sound.set_volume(0)
            explode_sound.set_volume(0)
            impulse_sound.set_volume(0)
            hit_sound.set_volume(0)
        else:
            effects_main.volume_btn(True)
            shoot_sound.set_volume(effects_vol)
            click_sound.set_volume(effects_vol)
            explode_sound.set_volume(effects_vol)
            impulse_sound.set_volume(effects_vol)
            hit_sound.set_volume(effects_vol)
    else:
        count = effects_btns.index(sender)
        volume_states = [False, False, False, False, False,
                         False, False, False, False, False]
        volume_states[count] = True
        for i in range(len(effects_btns)):
            effects_btns[i].state = volume_states[i]
        shoot_sound.set_volume((count + 1) / 10)
        click_sound.set_volume((count + 1) / 10)
        explode_sound.set_volume((count + 1) / 10)
        impulse_sound.set_volume((count + 1) / 10)
        hit_sound.set_volume((count + 1) / 10)
    settings_menu(screen)
    pygame.display.flip()


def reset_sprites():
    global all_sprites, enemies, enemies_healthbars, rockets, enemy_bullets
    all_sprites = pygame.sprite.Group()
    enemies = pygame.sprite.Group()
    enemies_healthbars = pygame.sprite.Group()
    rockets = pygame.sprite.Group()
    enemy_bullets = pygame.sprite.Group()


def play():
    global game_state, current_level, player_ship
    global current_health_image, current_level, current_score, save_count
    game_state = 1
    pygame.mouse.set_visible(False)

    reset_sprites()  # Сброс всех игровых данных:
    current_health_image = load_image(r"png/health100.png")
    current_health_image = pygame.transform.scale(current_health_image,
                                                  (60, 60))
    save_count = 0
    current_level = 1
    current_score = 0
    player_ship_image = load_image(r"png\plship0.png")
    player_ship = Player(all_sprites)
    player_ship.image = pygame.transform.rotate(player_ship.image, 90)
    player_ship.image = pygame.transform.scale(player_ship.image, (60, 60))

    a = levels(current_level)


class Rocket(pygame.sprite.Sprite):
    def __init__(self, group):
        super().__init__(group)
        self.image = rocket_image
        self.rect = self.image.get_rect()
        self.rect.x = player_ship.rect.centerx + 1
        self.rect.y = player_ship.rect.centery - 15

    def update(self):
        if self.rect.y > -25:
            self.rect.y -= 10
        else:
            rockets.remove(self)
            del self
        try:
            if pygame.sprite.spritecollideany(self, enemies):
                for sprite in enemies:
                    if self.rect.colliderect(sprite.rect):
                        if sprite.enemy_type == 0:
                            increase_score(sprite)
                            explode_sound.play()
                            enemies.remove(sprite)
                            del sprite
                            rockets.remove(self)
                            del self
                            break
                        elif sprite.enemy_type == 1:
                            if sprite.health > 0:
                                sprite.health -= 50
                                if sprite.health == 100:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health100png.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image, (60,
                                                                        15))
                                elif sprite.health >= 50:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health8.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image, (60,
                                                                        15))
                                else:
                                    increase_score(sprite)
                                    enemies_healthbars.remove(
                                        sprite.enemy_health)
                                    enemies.remove(sprite)
                                    enemies.remove(sprite.enemy_health)
                                    del sprite
                            else:
                                increase_score(sprite)
                                enemies_healthbars.remove(sprite.enemy_health)
                                enemies.remove(sprite)
                                enemies.remove(sprite.enemy_health)
                                del sprite
                            explode_sound.play()
                            rockets.remove(self)
                            del self
                            break
                        elif sprite.enemy_type == 2:
                            if sprite.health > 0:
                                sprite.health -= 100 // 3
                                if sprite.health == 100:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health100png.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image, (60,
                                                                        15))
                                elif sprite.health >= 100 // 3 * 2:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health11.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image, (60,
                                                                        15))
                                elif sprite.health >= 100 // 3:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health4.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image, (60,
                                                                        15))
                                else:
                                    increase_score(sprite)
                                    enemies_healthbars.remove(
                                        sprite.enemy_health)
                                    enemies.remove(sprite)
                                    enemies.remove(sprite.enemy_health)
                                    del sprite
                            else:
                                increase_score(sprite)
                                enemies_healthbars.remove(sprite.enemy_health)
                                enemies.remove(sprite)
                                enemies.remove(sprite.enemy_health)
                                del sprite
                            explode_sound.play()
                            rockets.remove(self)
                            del self
                            break
                        elif sprite.enemy_type == 3:
                            if sprite.health > 0:
                                sprite.health -= 100 // 16
                                if sprite.health == 100:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health100png.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16 * 15:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health15.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image, (60,
                                                                        15))
                                elif sprite.health >= 100 // 16 * 14:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health14.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image, (60,
                                                                        15))
                                elif sprite.health >= 100 // 16 * 13:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health13.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image, (60,
                                                                        15))
                                elif sprite.health >= 100 // 16 * 12:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health12.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16 * 11:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health11.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16 * 10:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health10.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16 * 9:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health9.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16 * 8:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health8.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16 * 7:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health7.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16 * 6:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health6.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16 * 5:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health5.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16 * 4:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health4.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16 * 3:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health3.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16 * 2:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health2.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                elif sprite.health >= 100 // 16:
                                    sprite.enemy_health.image = load_image(
                                        r"png\enemy_health1.png")
                                    sprite.enemy_health.image = \
                                        pygame.transform.scale(
                                            sprite.enemy_health.image,
                                            (60, 15))
                                else:
                                    increase_score(sprite)
                                    enemies_healthbars.remove(
                                        sprite.enemy_health)
                                    enemies.remove(sprite)
                                    enemies.remove(sprite.enemy_health)
                                    del sprite
                            else:
                                increase_score(sprite)
                                enemies_healthbars.remove(sprite.enemy_health)
                                enemies.remove(sprite)
                                enemies.remove(sprite.enemy_health)
                                del sprite
                            explode_sound.play()
                            rockets.remove(self)
                            del self
                            break
        except:
            pass


class Player(pygame.sprite.Sprite):
    def __init__(self, group):
        super().__init__(group)
        self.image = player_ship_image
        self.rect = self.image.get_rect()
        self.rect.x = width // 2 - self.image.get_width() // 2
        self.rect.y = 800
        self.health = 100

    def update(self, key):
        if key == buttons_or_arrows[1]:
            if self.rect.x - 5 > 0 and self.rect.x - 5 < width - \
                    player_ray_image.get_width() * 2:
                self.rect.x -= 5
        if key == buttons_or_arrows[0]:
            if self.rect.x + 5 > 0 and self.rect.x + 5 < width - \
                    player_ray_image.get_width() * 2:
                self.rect.x += 5
        if key == buttons_or_arrows[3]:
            if self.rect.y + 5 > height // 2 and self.rect.y + 5 < height - \
                    player_ray_image.get_height() * 2:
                self.rect.y += 5
        if key == buttons_or_arrows[2]:
            if self.rect.y - 5 > height // 2 and self.rect.y - 5 < height - \
                    player_ray_image.get_height() * 2:
                self.rect.y -= 5

    def shoot(self):
        pass

    def damaged(self, enemy):
        global game_state, screen, current_health_image, all_sprites
        global enemies, enemies_healthbars, rockets, enemy_bullets
        damage = 100 / 8
        if enemy.enemy.enemy_type == 1:
            damage = 100 / 7
        elif enemy.enemy.enemy_type == 2:
            damage = 100 / 6
        elif enemy.enemy.enemy_type == 3:
            damage = 100 / 5
        if self.health > 0:
            self.health -= damage
            if self.health == 100:
                current_health_image = load_image(r"png\health100.png")
            elif self.health >= 87.5:
                current_health_image = load_image(r"png\health7.png")
            elif self.health >= 75:
                current_health_image = load_image(r"png\health6.png")
            elif self.health >= 62.5:
                current_health_image = load_image(r"png\health5.png")
            elif self.health >= 50:
                current_health_image = load_image(r"png\health4.png")
            elif self.health >= 37.5:
                current_health_image = load_image(r"png\health3.png")
            elif self.health >= 25:
                current_health_image = load_image(r"png\health2.png")
            elif self.health >= 12.5:
                current_health_image = load_image(r"png\health1.png")
            current_health_image = pygame.transform.scale(current_health_image,
                                                          (60, 60))
        else:
            current_health_image = load_image(r"png\health0.png")
            pygame.mouse.set_visible(False)

            death_screen()

            reset_sprites()
            del current_health_image
            main_menu(screen)


class Enemy_health(pygame.sprite.Sprite):
    def __init__(self, group, health_image, x, y):
        super().__init__(group)
        self.image = health_image
        self.image = pygame.transform.scale(self.image, (60, 15))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y - 15
        self.start_x = x
        self.start_y = y
        self.cond = True

    def update(self):
        if self.rect.x < self.start_x + self.image.get_width() and \
                self.cond is True:
            self.rect.x += 1
            self.cond = True
        elif self.rect.x > self.start_x - self.image.get_width():
            self.rect.x -= 1
            self.cond = False
        elif self.rect.x < self.start_x + self.image.get_width():
            self.cond = True


class Enemy(pygame.sprite.Sprite):
    def __init__(self, group, enemy_image, x, y, enemy_type=0):
        super().__init__(group)
        self.image = enemy_image
        self.image = pygame.transform.rotate(self.image, -90)
        self.image = pygame.transform.scale(self.image, (60, 60))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.start_x = x
        self.start_y = y
        self.cond = True
        self.health = 100
        self.enemy_type = enemy_type
        self.time = pygame.time.get_ticks()
        self.delay = random.randint(5000, 20000)
        self.enemy_health = 0
        if self.enemy_type > 0:
            self.enemy_health = Enemy_health(enemies, load_image(
                r"png\enemy_health100.png"), x, y)
            if self.enemy_type == 1:
                self.delay = random.randint(5000, 15000)
            elif self.enemy_type == 2:
                self.delay = random.randint(5000, 10000)
            elif self.enemy_type == 3:
                self.delay = 1000

    def update(self):
        now = pygame.time.get_ticks()
        if now - self.time > self.delay:
            self.shoot()
            self.time = pygame.time.get_ticks()
            self.delay = random.randint(10000, 20000)
            if self.enemy_type > 0:
                if self.enemy_type == 1:
                    self.delay = random.randint(5000, 15000)
                elif self.enemy_type == 2:
                    self.delay = random.randint(5000, 10000)
                elif self.enemy_type == 3:
                    self.delay = 1000
        if self.rect.x < self.start_x + self.image.get_width() and \
                self.cond is True:
            self.rect.x += 1
            self.cond = True
        elif self.rect.x > self.start_x - self.image.get_width():
            self.rect.x -= 1
            self.cond = False
        elif self.rect.x < self.start_x + self.image.get_width():
            self.cond = True

    def shoot(self):
        bullet = Enemy_Bullet(enemy_bullets, player_ship.rect.centerx,
                              player_ship.rect.centery, self.rect, self)
        impulse_sound.play()

    def damaged(self, enemy):
        global game_state, screen, current_health_image
        if self.health > 0:
            self.health -= 100 / 8
            if self.health == 100:
                current_health_image = load_image(r"png\health100.png")
            elif self.health >= 87.5:
                current_health_image = load_image(r"png\health7.png")
            elif self.health >= 75:
                current_health_image = load_image(r"png\health6.png")
            elif self.health >= 62.5:
                current_health_image = load_image(r"png\health5.png")
            elif self.health >= 50:
                current_health_image = load_image(r"png\health4.png")
            elif self.health >= 37.5:
                current_health_image = load_image(r"png\health3.png")
            elif self.health >= 25:
                current_health_image = load_image(r"png\health2.png")
            elif self.health >= 12.5:
                current_health_image = load_image(r"png\health1.png")
            current_health_image = pygame.transform.scale(current_health_image,
                                                          (60, 60))
        else:
            pass  # здесь смерть и исчезновение спрайта


def start_screen():
    global current_level
    intro_text = [f"Уровень {current_level}", "",
                  "Чтобы продолжить нажмите Enter",
                  "Esc - выход"]
    fon = pygame.transform.scale(load_image('png\pause_background.png'),
                                 (screen.get_width(), screen.get_height()))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    count = 0
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('white'))
        intro_rect = string_rendered.get_rect()
        text_coord = height // 3 - intro_rect.height // 2 + (
                intro_rect.height + 5) * count
        intro_rect.y = text_coord
        intro_rect.x = width // 2 - intro_rect.width // 2
        screen.blit(string_rendered, intro_rect)
        count += 1
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    reset_sprites()
                    main_menu(screen)
                    return "Esc"
                elif event.key == pygame.K_RETURN:
                    return  # начинаем игру
        pygame.display.flip()
        clock.tick(60)


def sort_csv_file_records():
    try:
        players = {}
        with open('data/records.csv', mode='r') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=';')
            for row in csv_reader:
                players[row[0]] = int(row[1])
            players = dict(sorted(players.items(), key=lambda item: item[1],
                                  reverse=True))
        with open('data/records.csv', mode='w', newline="") as csv_file:
            writer = csv.writer(csv_file, delimiter=';', quotechar='"',
                                quoting=csv.QUOTE_MINIMAL)
            for key, value in players.items():
                writer.writerow([str(key), str(value)])
    except Exception as e:
        print("sort exception", e)


def death_text(name, result="Нет ошибок"):
    global current_level, current_score
    txt = "Поражение"
    if current_level > 10:
        txt = "Победа"
    sort_csv_file_records()
    lines = []
    try:
        with open('data/records.csv', mode='r') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=';')
            for row in csv_reader:
                if len(row) == 2:
                    lines.append(f"{row[0]} - {row[1]}")
                    lines.append("")
    except Exception as e:
        print("res table", e)

    if len(lines) > 10:
        lines = lines[:9]
    elif len(lines) <= 8:
        for i in range(10 - len(lines)):
            lines.append("свободное место - 0")
            lines.append("")
    intro_text = [txt, "",
                  f"Вы достигли {current_level} уровня со счётом"
                  f" {current_score}",
                  "",
                  "Таблица лидеров (топ-5)", "",
                  *lines, "",
                  f"Введите ваше имя: {name}", "",
                  result, ""
                          "Enter - записать результат", "",
                  "Esc - выход в меню"]
    fon = pygame.transform.scale(load_image('png\pause_background.png'),
                                 (screen.get_width(), screen.get_height()))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    count = 0
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('white'))
        intro_rect = string_rendered.get_rect()
        text_coord = 50 - intro_rect.height // 2 + (
                intro_rect.height + 5) * count
        intro_rect.y = text_coord
        intro_rect.x = width // 2 - intro_rect.width // 2
        screen.blit(string_rendered, intro_rect)
        count += 1


def death_screen():
    global current_level, current_score, save_count
    name, result = "", ""
    death_text(name)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                if event.key == pygame.K_ESCAPE:
                    return  # Выход в меню
                elif event.key == pygame.K_RETURN and save_count == 0:
                    with open('data/records.csv', mode='a+',
                              newline="") as csv_file:
                        players = {}
                        csv_reader = csv.reader(csv_file, delimiter=';')
                        for row in csv_reader:
                            players[row[0]] = row[1]
                        try:
                            if name not in players.keys() and len(name) >= 3:
                                writer = csv.writer(csv_file, delimiter=';',
                                                    quotechar='"',
                                                    quoting=csv.QUOTE_MINIMAL)
                                writer.writerow([name, current_score])
                                csv_file.close()
                                death_text("", "Имя сохранено")
                                save_count = 1
                            elif len(name) < 3:
                                death_text(name,
                                           "Имя должно содержать от 3 до 16 "
                                           "символов")
                            else:
                                death_text(name, "Такое имя уже существует")
                        except Exception:
                            pass
                elif event.key == pygame.K_BACKSPACE:
                    if len(name) <= 16 and len(name) > 0 and save_count == 0:
                        name = list(name)
                        del name[-1]
                        name = ''.join(name)
                        death_text(name)
                else:
                    try:
                        if str(pygame.key.name(
                                event.key)) in ascii_letters and \
                                len(name) < 16 and save_count == 0:
                            name += str(pygame.key.name(event.key))
                            death_text(name)
                    except Exception:
                        pass
        pygame.display.flip()
        clock.tick(60)


def levels(level):
    a = start_screen()
    if a == "Esc":
        return False
    if enemies.sprites() != list():
        return False
    if level == 1:  # Легко - 1
        img = enemy_ship_image0
        x = width // 2 - enemy_ship_image0.get_width() // 2
        enemy = Enemy(enemies, img, x, 20)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() + 40)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 2 + 80)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 3 + 120)
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x, 20)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 100 - \
            enemy_ship_image0.get_width() * 3
        for i in range(6):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() + 40)
            x += 40 + enemy_ship_image0.get_width()
            if i == 2:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 60 - \
            enemy_ship_image0.get_width() * 2
        for i in range(4):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 2 + 80)
            x += 40 + enemy_ship_image0.get_width()
            if i == 1:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 20 - \
            enemy_ship_image0.get_width()
        for i in range(2):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 3 + 120)
            x += 40 + enemy_ship_image0.get_width()
            if i == 0:
                x += 30 + enemy_ship_image0.get_width()
    elif level == 2:  # Легко - 2
        img = enemy_ship_image0
        x = width // 2 - enemy_ship_image0.get_width() // 2
        enemy = Enemy(enemies, img, x, 20)
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x, 20)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() + 40)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(6):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 2 + 80)
            x += 40 + enemy_ship_image0.get_width()
            if i == 2:
                x += 30 + enemy_ship_image0.get_width() * 3 + 80
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(4):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 3 + 120)
            x += 40 + enemy_ship_image0.get_width()
            if i == 1:
                x += 30 + enemy_ship_image0.get_width() * 5 + 160
    elif level == 3:  # Легко - 3
        img = enemy_ship_image0
        x = width // 2 - enemy_ship_image0.get_width() // 2
        enemy = Enemy(enemies, img, x, 20)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() + 40)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 2 + 80)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 3 + 120)
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x, 20)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(2):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 2 + 80)
            x += 40 + enemy_ship_image0.get_width()
            if i == 0:
                x += 30 + enemy_ship_image0.get_width()
                x += enemy_ship_image0.get_width() * 6 + 240
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(2):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() + 40)
            x += 40 + enemy_ship_image0.get_width()
            if i == 0:
                x += 30 + enemy_ship_image0.get_width()
                x += enemy_ship_image0.get_width() * 6 + 240
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 3 + 120)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
    elif level == 4:  # Средний - 1
        img = enemy_ship_image1
        x = width // 2 - enemy_ship_image0.get_width() // 2
        enemy = Enemy(enemies, img, x, 20, 1)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() + 40, 1)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 2 + 80, 1)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 3 + 120, 1)
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        img = enemy_ship_image0
        for i in range(8):
            enemy = Enemy(enemies, img, x, 20)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 100 - \
            enemy_ship_image0.get_width() * 3
        for i in range(6):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() + 40)
            x += 40 + enemy_ship_image0.get_width()
            if i == 2:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 60 - \
            enemy_ship_image0.get_width() * 2
        for i in range(4):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 2 + 80)
            x += 40 + enemy_ship_image0.get_width()
            if i == 1:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 20 - \
            enemy_ship_image0.get_width()
        for i in range(2):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 3 + 120)
            x += 40 + enemy_ship_image0.get_width()
            if i == 0:
                x += 30 + enemy_ship_image0.get_width()
    elif level == 5:  # Средний - 2
        img = enemy_ship_image1
        x = width // 2 - enemy_ship_image0.get_width() // 2
        enemy = Enemy(enemies, img, x, 20, 1)
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x, 20, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        img = enemy_ship_image0
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() + 40)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        img = enemy_ship_image1
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(6):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 2 + 80, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 2:
                x += 30 + enemy_ship_image0.get_width() * 3 + 80
        img = enemy_ship_image0
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(4):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 3 + 120)
            x += 40 + enemy_ship_image0.get_width()
            if i == 1:
                x += 30 + enemy_ship_image0.get_width() * 5 + 160
    elif level == 6:  # Средний - 3
        img = enemy_ship_image0
        x = width // 2 - enemy_ship_image0.get_width() // 2
        enemy = Enemy(enemies, img, x, 20)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() + 40)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 2 + 80)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 3 + 120)
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x, 20)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(2):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 2 + 80)
            x += 40 + enemy_ship_image0.get_width()
            if i == 0:
                x += 30 + enemy_ship_image0.get_width()
                x += enemy_ship_image0.get_width() * 6 + 240
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(2):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() + 40)
            x += 40 + enemy_ship_image0.get_width()
            if i == 0:
                x += 30 + enemy_ship_image0.get_width()
                x += enemy_ship_image0.get_width() * 6 + 240
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 3 + 120)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        img = enemy_ship_image1
        x = width // 2 - enemy_ship_image0.get_width() - 100 - \
            enemy_ship_image0.get_width() * 3
        for i in range(6):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 2 + 80, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 2:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 100 - \
            enemy_ship_image0.get_width() * 3
        for i in range(6):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() + 40, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 2:
                x += 30 + enemy_ship_image0.get_width()
    elif level == 7:  # Сложный - 1
        img = enemy_ship_image2
        x = width // 2 - enemy_ship_image0.get_width() // 2
        enemy = Enemy(enemies, img, x, 20, 2)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() + 40, 2)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 2 + 80, 2)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 3 + 120, 2)
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        img = enemy_ship_image1
        for i in range(8):
            enemy = Enemy(enemies, img, x, 20, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 100 - \
            enemy_ship_image0.get_width() * 3
        for i in range(6):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() + 40, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 2:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 60 - \
            enemy_ship_image0.get_width() * 2
        for i in range(4):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 2 + 80, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 1:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 20 - \
            enemy_ship_image0.get_width()
        for i in range(2):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 3 + 120, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 0:
                x += 30 + enemy_ship_image0.get_width()
    elif level == 8:  # Сложный - 2
        img = enemy_ship_image2
        x = width // 2 - enemy_ship_image0.get_width() // 2
        enemy = Enemy(enemies, img, x, 20, 2)
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x, 20, 2)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        img = enemy_ship_image1
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() + 40, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        img = enemy_ship_image2
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(6):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 2 + 80, 2)
            x += 40 + enemy_ship_image0.get_width()
            if i == 2:
                x += 30 + enemy_ship_image0.get_width() * 3 + 80
        img = enemy_ship_image1
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(4):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 3 + 120, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 1:
                x += 30 + enemy_ship_image0.get_width() * 5 + 160
    elif level == 9:  # Сложный - 3
        img = enemy_ship_image1
        x = width // 2 - enemy_ship_image0.get_width() // 2
        enemy = Enemy(enemies, img, x, 20, 1)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() + 40, 1)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 2 + 80, 1)
        enemy = Enemy(enemies, img, x,
                      20 + enemy_ship_image0.get_height() * 3 + 120, 1)
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x, 20, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(2):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 2 + 80, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 0:
                x += 30 + enemy_ship_image0.get_width()
                x += enemy_ship_image0.get_width() * 6 + 240
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(2):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() + 40, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 0:
                x += 30 + enemy_ship_image0.get_width()
                x += enemy_ship_image0.get_width() * 6 + 240
        x = width // 2 - enemy_ship_image0.get_width() - 140 - \
            enemy_ship_image0.get_width() * 4
        for i in range(8):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 3 + 120, 1)
            x += 40 + enemy_ship_image0.get_width()
            if i == 3:
                x += 30 + enemy_ship_image0.get_width()
        img = enemy_ship_image2
        x = width // 2 - enemy_ship_image0.get_width() - 100 - \
            enemy_ship_image0.get_width() * 3
        for i in range(6):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() * 2 + 80, 2)
            x += 40 + enemy_ship_image0.get_width()
            if i == 2:
                x += 30 + enemy_ship_image0.get_width()
        x = width // 2 - enemy_ship_image0.get_width() - 100 - \
            enemy_ship_image0.get_width() * 3
        for i in range(6):
            enemy = Enemy(enemies, img, x,
                          20 + enemy_ship_image0.get_height() + 40, 2)
            x += 40 + enemy_ship_image0.get_width()
            if i == 2:
                x += 30 + enemy_ship_image0.get_width()
    elif level == 10:  # Босс
        img = enemy_ship_image20
        x = width // 2 - img.get_width() // 2
        enemy = Enemy(enemies, img, x, 20 + img.get_height() + 40, 3)
    return True


class Enemy_Bullet(pygame.sprite.Sprite):
    def __init__(self, group, player_x, player_y, enemy_rect, enemy):
        super().__init__(group)
        self.image = enemy_bullet
        self.image = pygame.transform.rotate(self.image, -90)
        self.image = pygame.transform.scale(self.image, (30, 30))
        self.rect = self.image.get_rect()
        self.rect.x = enemy_rect.centerx + 1
        self.rect.y = enemy_rect.centery - 15
        self.player_x = player_x
        self.player_y = player_y
        self.angle = math.atan2((self.player_y - self.rect.y),
                                (self.player_x - self.rect.x))
        self.speed_x = round(math.cos(self.angle) * 10)
        self.speed_y = round(math.sin(self.angle) * 10)
        self.enemy = enemy

    def update(self):
        global current_score
        if self.rect.y > -25 and self.rect.y < height + 25 and \
                self.rect.x > -25 and self.rect.x < width + 25:
            self.rect.x += self.speed_x
            self.rect.y += self.speed_y
        else:
            enemy_bullets.remove(self)
            del self
        try:
            if self.rect.colliderect(player_ship.rect):
                hit_sound.play()
                enemy_bullets.remove(self)
                player_ship.damaged(self)
                del self
        except:
            pass


def increase_score(enemy):
    global current_score
    if enemy.enemy_type == 0:  # easy enemy
        current_score += 100
    elif enemy.enemy_type == 1:  # normal enemy
        current_score += 300
    elif enemy.enemy_type == 2:  # strong enemy
        current_score += 500
    elif enemy.enemy_type == 3:  # boss
        current_score += 25000


if __name__ == '__main__':
    pygame.init()
    clock = pygame.time.Clock()
    size = width, height = 1600, 900
    screen = pygame.display.set_mode(size,
                                     pygame.HWSURFACE | pygame.DOUBLEBUF |
                                     pygame.FULLSCREEN)
    running = True

    effects_vol = 0.1
    save_count = 0
    current_level = 1
    current_score = 0
    current_health_image = load_image(r"png/health100.png")
    current_health_image = pygame.transform.scale(current_health_image,
                                                  (60, 60))

    shoot_sound = pygame.mixer.Sound(r'data/sounds/rocket.wav')
    click_sound = pygame.mixer.Sound(r'data/sounds/click.wav')
    explode_sound = pygame.mixer.Sound(r'data/sounds/explode.WAV')
    impulse_sound = pygame.mixer.Sound(r'data/sounds/impulse.wav')
    hit_sound = pygame.mixer.Sound(r'data/sounds/hit.wav')
    shoot_sound.set_volume(effects_vol)
    click_sound.set_volume(effects_vol)
    explode_sound.set_volume(effects_vol)
    impulse_sound.set_volume(effects_vol)
    hit_sound.set_volume(effects_vol)

    enemy_bullet = load_image(r"png\star1.png")
    all_sprites = pygame.sprite.Group()

    player_ship_image = load_image(r"png\plship0.png")
    player_ship = Player(all_sprites)
    player_ship.image = pygame.transform.rotate(player_ship.image, 90)
    player_ship.image = pygame.transform.scale(player_ship.image, (60, 60))
    player_ray_image = load_image(r"png\rayDisabled.png")

    rockets = pygame.sprite.Group()
    enemy_bullets = pygame.sprite.Group()
    reload = False
    rocket_image = load_image(r"png\rocket.png")

    enemies = pygame.sprite.Group()
    enemies_healthbars = pygame.sprite.Group()
    enemy_ship_image0 = load_image(r"png\ship0.png")
    enemy_ship_image1 = load_image(r"png\ship1.png")
    enemy_ship_image2 = load_image(r"png\ship2.png")
    enemy_ship_image20 = load_image(r"png\ship20.png")

    font_header = pygame.font.Font(None, 30)
    font_text = pygame.font.Font(None, 24)
    fon = pygame.transform.scale(load_image(r'png\background.jpg'),
                                 (screen.get_width(), screen.get_height()))
    head1 = Button()
    head2 = Button()
    head3 = Button()
    play_btn = Button()
    settings_btn = Button()
    help_btn = Button()
    quit_btn = Button()

    game_state = 0  # 0 - меню, 1 - игра, 2 - настройки, 3 - предыстория

    volume_btns = []
    volume_states = [True, False, False, False, False, False, False, False,
                     False, False]
    for i in range(10):
        vol_btn = Button()
        volume_btns.append(vol_btn)
        vol_btn.volume_btn(volume_states[i])
    volume_main = Button()
    volume_main.volume_btn(True)

    effects_btns = []
    effects_states = [True, False, False, False, False, False, False, False,
                      False, False]
    for i in range(10):
        eff_btn = Button()
        effects_btns.append(eff_btn)
        eff_btn.volume_btn(effects_states[i])
    effects_main = Button()
    effects_main.volume_btn(True)

    box = Button()
    to_menu = Button()

    w_btn = Button()
    a_btn = Button()
    s_btn = Button()
    d_btn = Button()
    arrowUp_btn = Button()
    arrowLeft_btn = Button()
    arrowDown_btn = Button()
    arrowRight_btn = Button()
    w_btn.volume_btn(True)
    a_btn.volume_btn(True)
    s_btn.volume_btn(True)
    d_btn.volume_btn(True)
    arrowUp_btn.volume_btn(False)
    arrowLeft_btn.volume_btn(False)
    arrowDown_btn.volume_btn(False)
    arrowRight_btn.volume_btn(False)

    wasd_box = Button()
    arrow_box = Button()
    wasd_box.volume_btn(True)
    arrow_box.volume_btn(False)

    buttons_or_arrows = [pygame.K_d, pygame.K_a, pygame.K_w,
                         pygame.K_s]  # default: W A S D

    main_menu(screen)
    screen.blit(fon, (0, 0))

    pygame.mixer.music.load(r'data\sounds\HybridSong.ogg')
    pygame.mixer.music.play(-1)
    pygame.mixer.music.set_volume(0.1)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            if event.type == pygame.USEREVENT:
                reload = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if game_state == 0:  # Если в меню
                    if quit_btn.pressed(pygame.mouse.get_pos()):
                        terminate()
                    if help_btn.pressed(pygame.mouse.get_pos()):
                        other_menu(screen)
                    if settings_btn.pressed(pygame.mouse.get_pos()):
                        settings_menu(screen)
                if to_menu.pressed(pygame.mouse.get_pos()):
                    main_menu(screen)
                    click_sound.play()
                    pygame.display.flip()
                if volume_main.pressed(pygame.mouse.get_pos()):
                    volume(volume_main)
                if effects_main.pressed(pygame.mouse.get_pos()):
                    effects_volume(effects_main)
                if volume_main.state:
                    for i in volume_btns:
                        if i.pressed(pygame.mouse.get_pos()):
                            volume(i)
                if effects_main.state:
                    for i in effects_btns:
                        if i.pressed(pygame.mouse.get_pos()):
                            effects_volume(i)
                if game_state == 2:  # Если в игре
                    if wasd_box.pressed(pygame.mouse.get_pos()) \
                            and wasd_box.state is False:
                        buttons_or_arrows = [pygame.K_d, pygame.K_a,
                                             pygame.K_w, pygame.K_s]
                        wasd_box.volume_btn(True)
                        arrow_box.volume_btn(False)
                        w_btn.volume_btn(True)
                        a_btn.volume_btn(True)
                        s_btn.volume_btn(True)
                        d_btn.volume_btn(True)
                        arrowUp_btn.volume_btn(False)
                        arrowLeft_btn.volume_btn(False)
                        arrowDown_btn.volume_btn(False)
                        arrowRight_btn.volume_btn(False)
                        settings_menu(screen)
                    if arrow_box.pressed(pygame.mouse.get_pos()) and \
                            arrow_box.state is False:
                        buttons_or_arrows = [pygame.K_RIGHT, pygame.K_LEFT,
                                             pygame.K_UP, pygame.K_DOWN]
                        arrow_box.volume_btn(True)
                        wasd_box.volume_btn(False)
                        w_btn.volume_btn(False)
                        a_btn.volume_btn(False)
                        s_btn.volume_btn(False)
                        d_btn.volume_btn(False)
                        arrowUp_btn.volume_btn(True)
                        arrowLeft_btn.volume_btn(True)
                        arrowDown_btn.volume_btn(True)
                        arrowRight_btn.volume_btn(True)
                        settings_menu(screen)
                if play_btn.pressed(pygame.mouse.get_pos()):
                    play()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE and game_state > 1:
                    main_menu(screen)
                if game_state == 1:
                    if event.key == pygame.K_SPACE and reload is False:
                        rocket = Rocket(rockets)
                        rocket.image = pygame.transform.rotate(rocket.image,
                                                               90)
                        rocket.image = pygame.transform.scale(rocket.image,
                                                              (25, 25))
                        shoot_sound.play()
                        pygame.time.set_timer(pygame.USEREVENT, 1000)
                        reload = True
        keys = pygame.key.get_pressed()
        if game_state == 1:
            if keys[buttons_or_arrows[0]]:
                player_ship.update(buttons_or_arrows[0])
            if keys[buttons_or_arrows[1]]:
                player_ship.update(buttons_or_arrows[1])
            if keys[buttons_or_arrows[2]]:
                player_ship.update(buttons_or_arrows[2])
            if keys[buttons_or_arrows[3]]:
                player_ship.update(buttons_or_arrows[3])
        if game_state == 1:
            screen.blit(fon, (0, 0))
            all_sprites.draw(screen)
            if enemies.sprites() != list():
                enemies.draw(screen)
                enemies.update()
                enemies_healthbars.draw(screen)
                enemies_healthbars.update()
            elif current_level < 10:
                current_level += 1
                player_ship.health = 100
                current_health_image = load_image(r"png\health100.png")
                current_health_image = pygame.transform.scale(
                    current_health_image,
                    (60, 60))

                levels(current_level)
            elif current_level >= 10:
                death_screen()
            rockets.draw(screen)
            enemy_bullets.draw(screen)
            enemy_bullets.update()
            rockets.update()
            try:
                screen.blit(current_health_image,
                            (width - current_health_image.get_width() * 1.5,
                             current_health_image.get_height() // 2))
                text = font_header.render(f"{current_score}", True,
                                          (255, 255, 255))
                screen.blit(text, (20, 20))
            except Exception:
                pass
            pygame.display.flip()
        else:
            pygame.mouse.set_visible(True)
        clock.tick(60)
        pygame.event.pump()
